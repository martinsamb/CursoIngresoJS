function mostrar()
{
	var datoNombre;
	var datoLocalidad;

	datoNombre = elNombre.value;
	datoLocalidad = laLocalidad.value;

	alert("Bienvenidos");
	alert("Usted se llama " + datoNombre + " y vive el la localidad de " + datoLocalidad);
}
